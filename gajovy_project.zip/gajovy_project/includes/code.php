<?php
include('connection.php');


//Client Add Form
if(isset($_POST["Client_addBtn"])){
			$CP_firstname = mysqli_real_escape_string($connection , $_POST['Cp_Firstname']);
			$CP_lastname = mysqli_real_escape_string($connection , $_POST['Cp_Lastname']);
			$CP_age = mysqli_real_escape_string($connection , $_POST['Cp_Age']);
			$CP_Age_bracket = mysqli_real_escape_string($connection , $_POST['Cp_Age_bracket']);
			$CP_Gender = mysqli_real_escape_string($connection , $_POST['Cp_Gender']);
		$CP_marital_status = mysqli_real_escape_string($connection , $_POST['Cp_Marital_status']);
			$CP_mobileno = mysqli_real_escape_string($connection , $_POST['Cp_mobileno']);
			$CP_email = mysqli_real_escape_string($connection , $_POST['Cp_Email']);
			$CP_nationality = mysqli_real_escape_string($connection , $_POST['Cp_Nationality']);
			$CP_country = mysqli_real_escape_string($connection , $_POST['Cp_Country']);
			$CP_region = mysqli_real_escape_string($connection , $_POST['Cp_Region']);
			$CP_province = mysqli_real_escape_string($connection , $_POST['Cp_Province']);
			$CP_proffesion = mysqli_real_escape_string($connection , $_POST['Cp_Profession']);
			$CP_employment= mysqli_real_escape_string($connection , $_POST['Cp_Employment']);
		$CP_employment_g = mysqli_real_escape_string($connection , $_POST['Cp_Employment_group']);
	$CP_employment_c = mysqli_real_escape_string($connection , $_POST['Cp_Employment_country']);
	
$Add_Client_query="INSERT INTO clients_info (`CUST_Fname`,`CUST_Lname`,`CUST_Age`,`CUST_Age_bracket`,`CUST_Gender`,`CUST_Mobileno`,`CUST_Email_ad`,`CUST_Marital_status`,`CUST_Province`,`CUST_Country`,`CUST_Region`,`CUST_Nationality`,`CUST_Profession`,`CUST_Emp_country`,`CUST_Per_Employment_Group`,`CUST_Employment`) VALUES ('$CP_firstname','$CP_lastname','$CP_age','$CP_Age_bracket','$CP_Gender','$CP_mobileno','$CP_email','$CP_marital_status','$CP_province','$CP_country','$CP_region','$CP_nationality','$CP_proffesion','$CP_employment_c','$CP_employment_g','$CP_employment')";
	mysqli_query($connection, $Add_Client_query) or die(mysqli_error($connection));
	
	echo '<script>alert("Client Registered!")</script>';
  	echo"<script>window.location.href='../admin/Client_Regform.php';</script>";
}
?>